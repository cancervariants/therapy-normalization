"""Defines how metakb is packaged and distributed."""
from setuptools import setup

setup(version="0.2.10")
