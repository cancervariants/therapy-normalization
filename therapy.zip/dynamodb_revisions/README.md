# DynamoDB Revisions
Files in this directory are used to make updates to the `therapy_concepts` and/or `therapy_metadata` tables in DynamoDB.